package com.ecommerce.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.ecommerce.Model.Address; // This is the new part

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserResponse {
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private String mobile;
    private LocalDateTime createdAt;
    List<Address> addresses; 
}