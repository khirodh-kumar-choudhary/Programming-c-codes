package com.ecommerce.dto;

import com.ecommerce.Model.PaymentInformation;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PlaceOrderRequest {

    private Long userId;
    
    private Long addressId;
 
    private PaymentInformation paymentInformation;
}