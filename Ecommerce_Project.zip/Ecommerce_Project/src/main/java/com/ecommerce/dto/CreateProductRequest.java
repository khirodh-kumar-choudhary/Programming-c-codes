package com.ecommerce.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull; // Not directly used in this DTO after adding @NotBlank
import lombok.Data;
import com.ecommerce.Model.Size;

import java.util.HashSet;
import java.util.Set;

@Data
public class CreateProductRequest {

    @NotBlank(message = "Product name is required")
    private String name;

    @NotBlank(message = "Product description is required")
    private String description;

    @Min(value = 0, message = "Price cannot be negative")
    private int price;

    @NotBlank(message = "Image URL is required")
    private String imageUrl;

    @NotEmpty(message = "At least one size must be provided for the product")
    private Set<Size> sizes = new HashSet<>();

    @NotBlank(message = "Category is required")
    private String category;

    @Min(value = 0, message = "Discounted price cannot be negative")
    private int discountedPrice;

    @Min(value = 0, message = "Quantity cannot be negative")
    private int quantity;
}