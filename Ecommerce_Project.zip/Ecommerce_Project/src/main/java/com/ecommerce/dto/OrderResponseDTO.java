package com.ecommerce.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.ecommerce.Model.Address;
import com.ecommerce.Model.OrderItem;
import com.ecommerce.Model.PaymentInformation;
import com.ecommerce.Model.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponseDTO {
    private Long id;
    private User user;
    private List<OrderItem> orderItems = new ArrayList<>();
    private LocalDateTime orderDate;
    private LocalDateTime deliveryDate;
    private Address shippingAddress;
    private PaymentInformation paymentInformation; 
    private int totalPrice;
    private int totalDiscountedPrice;
    private int discount;
    private int totalItem;
    private String orderStatus;
    private String paymentStatus;
    private LocalDateTime createdAt;
}
