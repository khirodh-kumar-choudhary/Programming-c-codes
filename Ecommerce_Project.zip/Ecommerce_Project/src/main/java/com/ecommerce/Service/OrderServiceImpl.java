package com.ecommerce.Service;

import com.ecommerce.Exception.CartException;
import com.ecommerce.Exception.OrderException;
import com.ecommerce.Exception.ProductException;
import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.*;
import com.ecommerce.dto.*;
import com.ecommerce.Repository.AddressRepository;
import com.ecommerce.Repository.OrderItemRepository; // Make sure this is correctly injected
import com.ecommerce.Repository.OrderRepository;
import com.ecommerce.dto.PlaceOrderRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional; // Import for @Transactional

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors; // Import for stream operations

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private CartService cartService;

    @Autowired
    private ProductService productService; 

    @Autowired
    private UserService userService;

   
    @Autowired
    private OrderItemRepository orderItemRepository;

    @Autowired
    private AddressRepository addressRepository;

    @Override
    @Transactional 
    public OrderResponseDTO createOrder(PlaceOrderRequest req) throws UserException, ProductException, CartException {
        //Fetch User and Cart
        User user = userService.findUserById(req.getUserId());
        Cart userCart = cartService.findUserCart(req.getUserId());

        if (userCart == null || userCart.getCartItems().isEmpty()) {
            throw new CartException("Cart is empty for user: " + user.getFirstName());
        }

        Optional<Address> optionalAddress = addressRepository.findById(req.getAddressId());
        if (optionalAddress.isEmpty()) {
            throw new UserException("Shipping address not found with ID: " + req.getAddressId());
        }
        Address shippingAddress = optionalAddress.get();

        //  check if the address actually belongs to the user
        if (!shippingAddress.getUser().getId().equals(user.getId())) {
             throw new UserException("Provided address does not belong to the authenticated user.");
        }


        // create the Order
        Order createdOrder = new Order();
        createdOrder.setUser(user);
        createdOrder.setTotalPrice(userCart.getTotalPrice());
        createdOrder.setTotalDiscountedPrice(userCart.getTotalDiscountedPrice());
        createdOrder.setDiscount(userCart.getDiscount());
        createdOrder.setTotalItem(userCart.getTotalItem());
        createdOrder.setShippingAddress(shippingAddress);
        createdOrder.setPaymentInformation(req.getPaymentInformation());
        createdOrder.setOrderStatus("PENDING");
        createdOrder.setPaymentStatus("PENDING"); // -- pending initially
        createdOrder.setOrderDate(LocalDateTime.now());
        createdOrder.setCreatedAt(LocalDateTime.now());

     
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : userCart.getCartItems()) {
            OrderItem orderItem = new OrderItem();
            orderItem.setPrice(cartItem.getPrice());
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setSize(cartItem.getSize());
            orderItem.setUserId(cartItem.getUserId()); 
            orderItem.setDiscountedPrice(cartItem.getDiscountedPrice());
            orderItem.setCreatedAt(LocalDateTime.now());

            orderItem.setOrder(createdOrder); 

            orderItems.add(orderItem);

            // Update product stock
            Product product = cartItem.getProduct();
            if (product.getQuantity() < cartItem.getQuantity()) {
                throw new ProductException("Not enough stock for product: " + product.getName() + " (Requested: " + cartItem.getQuantity() + ", Available: " + product.getQuantity() + ")");
            }
            product.setQuantity(product.getQuantity() - cartItem.getQuantity());
           
            productService.updateProductbyId(product.getId(), product);
        }

     
        createdOrder.setOrderItems(orderItems);

     
        Order savedOrder = orderRepository.save(createdOrder);
        
        OrderResponseDTO dto = convertEntityToDto(savedOrder);
        
        userCart.getCartItems().clear();
        cartService.recalculateCartTotals(userCart); 

        return dto;
    }
    
    //mapper order to dto
    public OrderResponseDTO convertEntityToDto(Order savedOrder) {
    	OrderResponseDTO dto = new OrderResponseDTO(); 
    	
    	dto.setId(savedOrder.getId());
    	dto.setUser(savedOrder.getUser());
    	dto.setOrderItems(savedOrder.getOrderItems());
    	dto.setOrderDate(savedOrder.getOrderDate());
    	dto.setShippingAddress(savedOrder.getShippingAddress());
    	dto.setPaymentInformation(savedOrder.getPaymentInformation());
    	dto.setTotalPrice(savedOrder.getTotalPrice());
    	dto.setTotalDiscountedPrice(savedOrder.getTotalDiscountedPrice());
    	dto.setDiscount(savedOrder.getDiscount());
    	dto.setTotalItem(savedOrder.getTotalItem());
    	dto.setOrderStatus(savedOrder.getOrderStatus());
    	dto.setPaymentStatus(savedOrder.getPaymentStatus());
    	dto.setCreatedAt(savedOrder.getCreatedAt());
    	return dto;
    }



    @Override
    @Transactional 
    public Order findOrderById(Long orderId) throws OrderException {
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isEmpty()) {
            throw new OrderException("Order not found with ID: " + orderId);
        }
        
        return optionalOrder.get();
    }

    @Override
    @Transactional
    public List<Order> usersOrderHistory(Long userId) throws UserException {
        User user = userService.findUserById(userId);
      
        return orderRepository.findByUser(user);
    }

    @Override
    @Transactional
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    @Override
    @Transactional
    public Order confirmOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("CONFIRMED");
        return orderRepository.save(order);
    }

    @Override
    @Transactional
    public Order shipOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("SHIPPED");
        order.setDeliveryDate(LocalDateTime.now().plusDays(5));
        return orderRepository.save(order);
    }

    @Override
    @Transactional
    public Order deliverOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("DELIVERED");
        order.setPaymentStatus("COMPLETED"); 
        order.setDeliveryDate(LocalDateTime.now());
        return orderRepository.save(order);
    }

    @Override
    @Transactional
    public Order cancelOrder(Long orderId) throws OrderException {
        Order order = findOrderById(orderId);
        order.setOrderStatus("CANCELLED");
   
        return orderRepository.save(order);
    }
}