package com.ecommerce.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.Exception.ProductException;
import com.ecommerce.Model.Category;
import com.ecommerce.Model.Product;
import com.ecommerce.Repository.CategoryRepository;
import com.ecommerce.Repository.ProductRepository;
import com.ecommerce.Repository.UserRepository;
import com.ecommerce.dto.CreateProductRequest;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class ProductServiceImpl implements ProductService{
	
	//private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	private ProductRepository productRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CategoryRepository categoryRepository;


	@Override
	public Product createProduct(CreateProductRequest createReq) {
		// TODO Auto-generated method stub

		//For category
		 String categoryName = createReq.getCategory();
		 Category category = categoryRepository.findByName(categoryName);
		 if (category == null) {
		  Category newCategory = new Category();
		 newCategory.setName(categoryName);
		  category = categoryRepository.save(newCategory);
		  log.info("New category '{}' created successfully with ID: {}.", category.getName(), category.getId());
		 } else {
	            log.debug("Category '{}' found for product creation (ID: {}).", categoryName, category.getId());
	        }

		 Product newProduct = new Product();
		 newProduct.setName(createReq.getName());
		 newProduct.setDescription(createReq.getDescription());
		 newProduct.setPrice(createReq.getPrice());
		 newProduct.setImageUrl(createReq.getImageUrl());
		 newProduct.setDiscountedPrice(createReq.getDiscountedPrice());
		 newProduct.setQuantity(createReq.getQuantity());
		 newProduct.setSizes(createReq.getSizes());
		 newProduct.setCategory(category);
		 newProduct.setCreatedAt(LocalDateTime.now());

		 Product savedProduct = productRepository.save(newProduct);
		 log.info("Product created successfully with ID: {}", savedProduct.getId());
		 return savedProduct;

	}

	@Override
	public String deleteProductById(Long productId) throws ProductException {
		// TODO Auto-generated method stub
		 if (!productRepository.existsById(productId)) {
	throw new ProductException("Product with ID " + productId + " not found");
	}
	productRepository.deleteById(productId);
	 log.info("Product with ID {} deleted successfully.", productId);
	return "Product with ID " + productId + " deleted successfully";
	}

	// Update
	@Override
	public Product updateProductbyId(Long productId, Product updateProduct) throws ProductException {

		Product existingProduct = productRepository.findById(productId)
	.orElseThrow(() -> new ProductException("Product with ID " + productId + " not found"));


	if (updateProduct.getName() != null) {
	existingProduct.setName(updateProduct.getName());
	}
	if (updateProduct.getDescription() != null) {
	 existingProduct.setDescription(updateProduct.getDescription());
	}
	 if (updateProduct.getPrice() != 0) {
	 existingProduct.setPrice(updateProduct.getPrice());
	}
	 if (updateProduct.getImageUrl() != null) {
	 existingProduct.setImageUrl(updateProduct.getImageUrl());
	}
	 if (updateProduct.getDiscountedPrice() != 0) {
	 existingProduct.setDiscountedPrice(updateProduct.getDiscountedPrice());
	}
	 if (updateProduct.getQuantity() != 0) {
	 existingProduct.setQuantity(updateProduct.getQuantity());
	}
	if (updateProduct.getSizes() != null) {
	 existingProduct.setSizes(updateProduct.getSizes());
	}
	 if (updateProduct.getCategory() != null) {
	 Category category = categoryRepository.findByName(updateProduct.getCategory().getName());
	 if (category == null) {
	 throw new IllegalArgumentException("Category '" + updateProduct.getCategory().getName() + "' does not exist.");
	}
	 existingProduct.setCategory(category);
	}

	 Product savedProduct = productRepository.save(existingProduct);
     log.info("Product with ID {} updated successfully.", savedProduct.getId());
     return savedProduct;
	}

	@Override
	public Product findProductsById(Long productId) throws ProductException {
		Optional<Product> optional = productRepository.findById(productId);

		if (optional.isPresent()) {
			return optional.get();

		}
		throw new ProductException("Product not found with id - "+productId);
	}

	@Override
	public List<Product> findProductByCategory(String categoryName) {
		// TODO Auto-generated method stub
		Category category = categoryRepository.findByName(categoryName);
		if(category != null) {
			return productRepository.findByCategory(category);
		}
	
		return List.of();
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		 List<Product> products = productRepository.findAll();
	        log.info("Retrieved {} products in total.", products.size());
	        return products;
	}

}