package com.ecommerce.Service;

import com.ecommerce.Exception.CartException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.ecommerce.Exception.ProductException;
import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.Cart;
import com.ecommerce.Model.CartItem;
import com.ecommerce.Model.Product;
import com.ecommerce.Model.User;
import com.ecommerce.Repository.CartItemRepository;
import com.ecommerce.Repository.CartRepository;
import com.ecommerce.dto.AddItemRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Slf4j
@Service
public class CartServiceImpl implements CartService {
	
	//private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);


    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private UserService userService; 

    @Override
    public Cart createCart(User user) {
        Cart cart = new Cart();
        cart.setUser(user);
        cart.setCreatedAt(LocalDateTime.now());
        return cartRepository.save(cart);
    }

    @Override
    public CartItem addCartItem(Long userId, AddItemRequest req) throws CartException, ProductException {
        try {
            User user = userService.findUserById(userId);
            Cart cart = cartRepository.findByUser(user);

            if (cart == null) {
                cart = createCart(user);
            }

            Product product = productService.findProductsById(req.getProductId());

            if (product == null) {
                throw new ProductException("Product not found with ID: " + req.getProductId());
            }
            //First checks if cart item is already exist or not 
            CartItem isExist = cartItemRepository.isCartItemExist(cart, product, userId, req.getSize());

            if (isExist != null) {
                // Item already in cart then update quantity
                isExist.setQuantity(isExist.getQuantity() + req.getQuantity());
                isExist.setPrice(isExist.getQuantity() * product.getPrice());
                isExist.setDiscountedPrice(isExist.getQuantity() * product.getDiscountedPrice());
                return cartItemRepository.save(isExist);
            } else {
                // else add new item to cart
                CartItem cartItem = new CartItem();
                cartItem.setProduct(product);
                cartItem.setCart(cart);
                cartItem.setQuantity(req.getQuantity());
                cartItem.setUserId(userId);
                cartItem.setSize(req.getSize());
                cartItem.setPrice(req.getQuantity() * product.getPrice());
                cartItem.setDiscountedPrice(req.getQuantity() * product.getDiscountedPrice());
                cartItem.setCreatedAt(LocalDateTime.now());

                CartItem savedCartItem = cartItemRepository.save(cartItem);
                cart.getCartItems().add(savedCartItem);
                recalculateCartTotals(cart); // Recalculate totals after adding
                log.info("Item successfully added to cart.");
                return savedCartItem;
            }
        } catch (UserException e) {
            throw new CartException("User not found: " + e.getMessage());
        }
    }

    @Override
    public Cart findUserCart(Long userId) throws CartException {
        try {
            User user = userService.findUserById(userId);
            Cart cart = cartRepository.findByUser(user);

            if (cart == null) {
                throw new CartException("Cart not found for user ID: " + userId);
            }
         // # Calculate the total cart item and Price 
            return recalculateCartTotals(cart); 
        } catch (UserException e) {
            throw new CartException("User not found: " + e.getMessage());
        }
    }

    @Override
    public CartItem updateCartItemQuantity(Long userId, Long cartItemId, int quantity) throws CartException, ProductException {
        Optional<CartItem> optionalCartItem = cartItemRepository.findById(cartItemId);

        if (optionalCartItem.isEmpty()) {
            throw new CartException("Cart item not found with ID: " + cartItemId);
        }

        CartItem cartItem = optionalCartItem.get();

        if (!cartItem.getUserId().equals(userId)) {
            throw new CartException("You are not authorized to update this cart item.");
        }

        Product product = cartItem.getProduct();
        if (product.getQuantity() < quantity) {
            throw new ProductException("Not enough stock for product: " + product.getName() + ". Available: " + product.getQuantity());
        }

        cartItem.setQuantity(quantity);
        cartItem.setPrice(quantity * product.getPrice());
        cartItem.setDiscountedPrice(quantity * product.getDiscountedPrice());

        CartItem updatedCartItem = cartItemRepository.save(cartItem);
        recalculateCartTotals(updatedCartItem.getCart()); // Recalculate totals after update
        log.info("Updated cart item");
        return updatedCartItem;
    }

    @Override
    @Transactional
    public String removeCartItem(Long userId, Long cartItemId) throws CartException, ProductException {
        Optional<CartItem> optionalCartItem = cartItemRepository.findById(cartItemId);

        if (optionalCartItem.isEmpty()) {
            throw new CartException("Cart item not found with ID: " + cartItemId);
        }

        CartItem cartItem = optionalCartItem.get();

        if (!cartItem.getUserId().equals(userId)) {
            throw new CartException("You are not authorized to remove this cart item.");
        }

        Cart cart = cartItem.getCart();
        cart.getCartItems().remove(cartItem);
        cartItemRepository.delete(cartItem);

        recalculateCartTotals(cart); 
        return "Cart item removed successfully.";
    }

    @Override //Calculate the total item and Item Price 
    public Cart recalculateCartTotals(Cart cart) {
        int totalItems = 0;
        int totalPrice = 0;
        int totalDiscountedPrice = 0;

        for (CartItem item : cart.getCartItems()) {
            totalItems += item.getQuantity();
            totalPrice += item.getPrice();
            totalDiscountedPrice += item.getDiscountedPrice();
        }

        cart.setTotalItem(totalItems);
        cart.setTotalPrice(totalPrice);
        cart.setTotalDiscountedPrice(totalDiscountedPrice);

        if (totalPrice > 0) {
            int discount = ((totalPrice - totalDiscountedPrice) * 100) / totalPrice;
            cart.setDiscount(discount);
        } else {
            cart.setDiscount(0);
        }

        return cartRepository.save(cart);
    }
}