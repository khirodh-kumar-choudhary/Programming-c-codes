package com.ecommerce.Service;

import com.ecommerce.Exception.CartException;
import com.ecommerce.Exception.ProductException;
import com.ecommerce.Model.Cart;
import com.ecommerce.Model.CartItem;
import com.ecommerce.Model.User;
import com.ecommerce.dto.AddItemRequest;

public interface CartService {

    // Creates a cart for a new user
    Cart createCart(User user);

    // Adds a product to the cart or updates quantity if already exists
    CartItem addCartItem(Long userId, AddItemRequest req) throws CartException, ProductException;

    // Finds a cart by user ID
    Cart findUserCart(Long userId) throws CartException;

    // Updates the cart item's quantity
    CartItem updateCartItemQuantity(Long userId, Long cartItemId, int quantity) throws CartException, ProductException;

    // Removes a product from the cart
    String removeCartItem(Long userId, Long cartItemId) throws CartException, ProductException;

    // Recalculates total price and items in the cart
    Cart recalculateCartTotals(Cart cart);
}