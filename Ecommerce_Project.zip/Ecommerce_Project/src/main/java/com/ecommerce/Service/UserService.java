package com.ecommerce.Service;

import java.util.List;

import java.util.Optional;
import java.time.LocalDateTime;
import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.User;

public interface UserService {

    // Register a new user
    User registerUser(User user) throws UserException;

    // Login user by email and password
    Optional<User> loginUser(String email, String password) throws UserException;

    // Get user by ID
    User findUserById(Long userId) throws UserException;

    // Get all users
    List<User> getAllUsers();

    // Update user profile
    User updateUser(User user) throws UserException;

    // Delete user by ID
    void deleteUser(Long userId) throws UserException;
}