package com.ecommerce.Service;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy; // Import Lazy
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.Address;
import com.ecommerce.Model.User;
import com.ecommerce.Repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
	
	//private static final Logger log = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Lazy 
    @Autowired
    private CartService cartService; 
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public User registerUser(User user) throws UserException {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
        	log.warn("Registration failed: Email {} already exists", user.getEmail());
            throw new UserException("Email already registered");
        }

        user.setCreatedAt(LocalDateTime.now());
        
       
        if (user.getAddress() != null) {
            for (Address address : user.getAddress()) {
                address.setUser(user); 
            }
        }
        
        // encrypt the password using PasswordEncoder and save
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        
        User registeredUser = userRepository.save(user);
        log.info("User registered successfully with ID: {}", registeredUser.getId());
       
        cartService.createCart(registeredUser);

        return registeredUser;
    }

  
    @Override
    public Optional<User> loginUser(String email, String password) throws UserException {
        Optional<User> userOptional = userRepository.findByEmail(email);

        if (userOptional.isEmpty()) {
        	log.warn("Login failed: User not found with email {}", email);
            throw new UserException("User not found with email: " + email);
        }

        User user = userOptional.get();

        if (!user.getPassword().equals(password)) {
        	log.warn("Login failed for user {}: Invalid password", email);
            throw new UserException("Invalid password.");
        }
        log.info("Login successful for user: {}", email);
        return userOptional;
    }

   
    @Override
    @Transactional
    public User findUserById(Long userId) throws UserException {
        return userRepository.findById(userId)
                .orElseThrow(() -> new UserException("User not found with ID: " + userId));
    }

    @Override
    @Transactional
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    @Transactional
    public User updateUser(User user) throws UserException {
        if (!userRepository.existsById(user.getId())) {
            throw new UserException("User not found with ID: " + user.getId());
        }
        if (user.getAddress() != null) {
            for (Address address : user.getAddress()) {
               
                address.setUser(user);
            }
        }
        
        log.info("Successfull Updation");
        return userRepository.save(user);
    }

    @Override
    public void deleteUser(Long userId) throws UserException {
        if (!userRepository.existsById(userId)) {
            throw new UserException("User not found with ID: " + userId);
        }
        userRepository.deleteById(userId);
    }
}