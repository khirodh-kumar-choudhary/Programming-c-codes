package com.ecommerce.Service;

import com.ecommerce.Exception.CartException;
import com.ecommerce.dto.*;
import com.ecommerce.Exception.OrderException;
import com.ecommerce.Exception.ProductException;
import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.Address;
import com.ecommerce.Model.Order;
import com.ecommerce.Model.User;
import com.ecommerce.dto.PlaceOrderRequest;

import java.util.List;

public interface OrderService {

    // Create a new order from a user's cart
	OrderResponseDTO createOrder(PlaceOrderRequest req) throws UserException, ProductException, CartException;

    // Find an order by its ID
    Order findOrderById(Long orderId) throws OrderException;

    // Get all orders for a specific user
    List<Order> usersOrderHistory(Long userId) throws UserException;

    //  Get all orders - ADMIN
    List<Order> getAllOrders();

    //  Confirm an order - ADMIN
    Order confirmOrder(Long orderId) throws OrderException;

    // Ship an order - ADMIN
    Order shipOrder(Long orderId) throws OrderException;

    // Deliver an order - ADMIN
    Order deliverOrder(Long orderId) throws OrderException;

    //  Cancel an order - ADMIN
    Order cancelOrder(Long orderId) throws OrderException;
}