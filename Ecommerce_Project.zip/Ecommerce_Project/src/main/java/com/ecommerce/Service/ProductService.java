package com.ecommerce.Service;



import java.util.List;



import com.ecommerce.Exception.ProductException;
import com.ecommerce.Model.Product;
import com.ecommerce.dto.CreateProductRequest;


public interface ProductService {

	//Done
	public Product createProduct(CreateProductRequest createReq);

	//Done
	public String deleteProductById(Long productId) throws ProductException;


	 public Product updateProductbyId(Long productId, Product updateProduct) throws ProductException;

	 //Done
	 public Product findProductsById(Long productId) throws ProductException;

	 //Done
	 public List<Product> findProductByCategory(String categoryName);

	 //Done
	 public List<Product> getProducts();

	// public Page<Product> getAllProducts(String category, List<String> sizes, Integer )

}