package com.ecommerce.Exception;

public class ProductException extends Exception {
	
	public ProductException(String message) {
		super(message);
	}

}
