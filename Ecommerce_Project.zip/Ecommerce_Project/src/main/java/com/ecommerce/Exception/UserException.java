package com.ecommerce.Exception;

public class UserException extends Exception {
	
	public UserException(String message) {
		super(message);
	}

}
