package com.ecommerce.Repository;

import com.ecommerce.Model.Cart;
import com.ecommerce.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartRepository extends JpaRepository<Cart, Long> {
    Cart findByUser(User user);
}