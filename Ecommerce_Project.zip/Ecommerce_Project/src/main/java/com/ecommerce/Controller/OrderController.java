package com.ecommerce.Controller;

import com.ecommerce.Exception.CartException;
import com.ecommerce.Exception.OrderException;
import com.ecommerce.Exception.ProductException;
import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.Order;
import com.ecommerce.Service.OrderService;
import com.ecommerce.dto.PlaceOrderRequest;
import com.ecommerce.dto.OrderResponseDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    //Place a new order
    @PostMapping("/place")
    public ResponseEntity<OrderResponseDTO> placeOrder(@RequestBody PlaceOrderRequest req)
            throws UserException, ProductException, CartException {
        OrderResponseDTO orderResponseDTO = orderService.createOrder(req);
        return ResponseEntity.status(HttpStatus.CREATED).body(orderResponseDTO);
    }

    // Get an order by ID
    @GetMapping("/{orderId}")
    public ResponseEntity<Order> findOrderById(@PathVariable Long orderId) throws OrderException {
        Order order = orderService.findOrderById(orderId);
        return ResponseEntity.ok(order);
    }

    // Get user's order history
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> usersOrderHistory(@PathVariable Long userId) throws UserException {
        List<Order> orders = orderService.usersOrderHistory(userId);
        return ResponseEntity.ok(orders);
    }

    // Admin Task - Get all orders
    @GetMapping("/admin")
    public ResponseEntity<List<Order>> getAllOrders() {
        List<Order> orders = orderService.getAllOrders();
        return ResponseEntity.ok(orders);
    }

    // Admin Task - Confirm order
    @PutMapping("/admin/{orderId}/confirm")
    public ResponseEntity<Order> confirmOrder(@PathVariable Long orderId) throws OrderException {
        Order order = orderService.confirmOrder(orderId);
        return ResponseEntity.ok(order);
    }

    // Admin Task - Ship order
    @PutMapping("/admin/{orderId}/ship")
    public ResponseEntity<Order> shipOrder(@PathVariable Long orderId) throws OrderException {
        Order order = orderService.shipOrder(orderId);
        return ResponseEntity.ok(order);
    }

    // Admin Task - Deliver order
    @PutMapping("/admin/{orderId}/deliver")
    public ResponseEntity<Order> deliverOrder(@PathVariable Long orderId) throws OrderException {
        Order order = orderService.deliverOrder(orderId);
        return ResponseEntity.ok(order);
    }

    // Admin Task - Cancel order
    @PutMapping("/admin/{orderId}/cancel")
    public ResponseEntity<Order> cancelOrder(@PathVariable Long orderId) throws OrderException {
        Order order = orderService.cancelOrder(orderId);
        return ResponseEntity.ok(order);
    }
}
