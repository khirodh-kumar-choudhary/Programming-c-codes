package com.ecommerce.Controller;

import com.ecommerce.Exception.CartException;
import com.ecommerce.Exception.ProductException;
import com.ecommerce.Model.Cart;
import com.ecommerce.Model.CartItem;
import com.ecommerce.Service.CartService;
import com.ecommerce.dto.AddItemRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    // Get a user's cart
    @GetMapping("/{userId}")
    public ResponseEntity<Cart> findUserCart(@PathVariable Long userId) throws CartException {
        Cart cart = cartService.findUserCart(userId);
        return ResponseEntity.ok(cart);
    }

    // Add item to cart
    @PostMapping("/add")
    public ResponseEntity<CartItem> addCartItem(@RequestBody AddItemRequest req) throws CartException, ProductException {
        CartItem cartItem = cartService.addCartItem(req.getUserId(), req);
        return ResponseEntity.status(HttpStatus.CREATED).body(cartItem);
    }

    // Update cart item quantity
    @PutMapping("/update/{cartItemId}")
    public ResponseEntity<CartItem> updateCartItem(@PathVariable Long cartItemId,
                                                   @RequestParam int quantity,
                                                   @RequestParam Long userId) throws CartException, ProductException {
        CartItem updatedCartItem = cartService.updateCartItemQuantity(userId, cartItemId, quantity);
        return ResponseEntity.ok(updatedCartItem);
    }

    // Remove item from cart
    @DeleteMapping("/remove/{cartItemId}")
    public ResponseEntity<String> removeCartItem(@PathVariable Long cartItemId,
                                                 @RequestParam Long userId) throws CartException, ProductException {
        String message = cartService.removeCartItem(userId, cartItemId);
        return ResponseEntity.ok(message);
    }
}
