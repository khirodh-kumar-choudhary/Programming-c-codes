package com.ecommerce.Controller;

import java.util.List;
import java.util.Objects;

import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import java.util.Optional;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.Exception.UserException;
import com.ecommerce.Model.User;
import com.ecommerce.Service.CustomUserServiceImplementation;
import com.ecommerce.Service.UserService;
import com.ecommerce.config.JwtProvider;
import com.ecommerce.dto.AuthResponse;
import com.ecommerce.dto.LoginRequest;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
	private PasswordEncoder passwordEncoder;
    
	@Autowired
	private JwtProvider jwtProvider;
	@Autowired
	private CustomUserServiceImplementation customUserServiceImplementation;


    // Register a new user
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> registerUser(@Valid @RequestBody User user) throws UserException {
        User registeredUser = userService.registerUser(user);
        
        Authentication authentication = new UsernamePasswordAuthenticationToken(user.getEmail(), registeredUser.getPassword());
		
        SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String token = jwtProvider.generateToken(authentication);
		

		AuthResponse response = new AuthResponse(token, "Sign up successfull");
		
		return new ResponseEntity<AuthResponse>(response, HttpStatus.CREATED);
    }

    // Login user
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> loginUser(@RequestBody LoginRequest loginRequest) throws UserException {
    	
    	String email = loginRequest.getEmail();
		String password = loginRequest.getPassword();
		
		Authentication authentication = authenticate(email, password);
		
		AuthResponse response = null;
		
		if(!Objects.isNull(authentication) && authentication.isAuthenticated()) {
			
		SecurityContextHolder.getContext().setAuthentication(authentication);
		
		String token = jwtProvider.generateToken(authentication);
		
		response = new AuthResponse(token, "Sign in successfull");
		
		return new ResponseEntity<AuthResponse>(response, HttpStatus.CREATED);
		
		}
		
		response = new AuthResponse(null, "Invalid credentials");
		
		return new ResponseEntity<AuthResponse>(response, HttpStatus.FORBIDDEN);
    }

    // Get all users
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users);
    }

    // Get user by ID
    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) throws UserException {
        User user = userService.findUserById(id);
        return ResponseEntity.ok(user);
    }

    // Update user (Done by user itself)
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) throws UserException {
        user.setId(id);
        User updatedUser = userService.updateUser(user);
        return ResponseEntity.ok(updatedUser);
    }

    // Delete user (Can be done by admin)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) throws UserException {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
    
	public Authentication authenticate(String email, String password) {
		
		UserDetails userDetails = customUserServiceImplementation.loadUserByUsername(email);
		
		if(userDetails == null) {
			throw new BadCredentialsException("user not found with email - " + email);
		}
		
		if(!passwordEncoder.matches(password, userDetails.getPassword())) {
			throw new BadCredentialsException("Invalid Password ..!");
		}
		
		return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
	}
	
}
