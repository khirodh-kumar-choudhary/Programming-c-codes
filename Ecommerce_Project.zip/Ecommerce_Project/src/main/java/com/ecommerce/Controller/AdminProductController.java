package com.ecommerce.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ecommerce.Exception.ProductException;
import com.ecommerce.Model.Product;
import com.ecommerce.Service.ProductService;
import com.ecommerce.dto.CreateProductRequest;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin/products")
public class AdminProductController {

    @Autowired
    ProductService productService;

    // Create Product
    @PostMapping("/createproduct")
    public ResponseEntity<Product> createProduct(@Valid @RequestBody CreateProductRequest req) throws ProductException {
        Product createdProduct = productService.createProduct(req);
        return ResponseEntity.ok(createdProduct);
    }

    // Get all Products 
    @GetMapping("/findall")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = productService.getProducts();
        return ResponseEntity.ok(products);
    }

    // Find Products By ID 
    @GetMapping("/{productId}")
    public ResponseEntity<Product> findProductById(@PathVariable Long productId) throws ProductException {
        Product product = productService.findProductsById(productId);
        return ResponseEntity.ok(product);
    }

    // Find Products By Category 
    @GetMapping("/category")
    public ResponseEntity<List<Product>> findProductsByCategory(@RequestParam("name") String categoryName) throws ProductException {
        List<Product> products = productService.findProductByCategory(categoryName);
        return ResponseEntity.ok(products);
    }

    // Delete Product By Id 
    @DeleteMapping("/{productId}")
    public ResponseEntity<String> deleteProductById(@PathVariable Long productId) throws ProductException {
        String status = productService.deleteProductById(productId);
        return ResponseEntity.ok(status);
    }

    // Update Product By Id
    @PutMapping("/{productId}")
    public ResponseEntity<Product> updateProductbyId(@PathVariable Long productId, @RequestBody Product updateProduct) throws ProductException {
        Product updatedProduct = productService.updateProductbyId(productId, updateProduct);
        return ResponseEntity.ok(updatedProduct);
    }
}
