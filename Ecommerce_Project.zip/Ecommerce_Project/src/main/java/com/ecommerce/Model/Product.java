package com.ecommerce.Model;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	 @Column(name = "name")
	private String name;


    @Column(name = "description")
    private String description;

    @Column(name = "price")
    private int price;

    @Column(name = "image_url")
    private String imageUrl;
    
    
    //Extra fields 
    @Column(name = "discounted_price")
    private int discountedPrice;

    @Column(name = "quantity")
    private int quantity;
    
    @Embedded
    @ElementCollection
    @Column(name = "sizes")
    private Set<Size> sizes=new HashSet<>();

    @ManyToOne()
    @JoinColumn(name="category_id")
    private Category category;
   

    
    private LocalDateTime createdAt;
    
    


    

}
