package com.ecommerce.config;

public class JwtConstant {
	public static final String SECRET_KEY = "alsksjdhdfgcbcnzmalsjdueuwyrtreuwuwioqslkksdndckdjcbhfvwec bfweh";
	public static final String JWT_HEADER = "Authorization";
}
