package com.ecommerce.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;

import jakarta.servlet.http.HttpServletRequest;

@Configuration
public class SecurityConfig {
	
	@Autowired
	private JwtValidator jwtValidator;

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		
            http
        		.csrf(csrf -> csrf.disable())
        		.sessionManagement(management -> management.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
        		.addFilterBefore(jwtValidator, BasicAuthenticationFilter.class)
                .authorizeHttpRequests(Authorize -> Authorize
                		.requestMatchers(HttpMethod.POST,"/api/users/login").permitAll()
                		.requestMatchers(HttpMethod.GET, "/api/users/test").permitAll()
                        .anyRequest().authenticated())
                .cors(cors -> cors.configurationSource(customCorsConfig()));
		
		return http.build();
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	private CorsConfigurationSource customCorsConfig() {
	    return request -> {
	        CorsConfiguration cfg = new CorsConfiguration();
	        cfg.setAllowedOrigins(List.of("http://localhost:3000"));
	        cfg.setAllowedMethods(List.of("*"));
	        cfg.setAllowCredentials(true);
	        cfg.setAllowedHeaders(List.of("*"));
	        cfg.setExposedHeaders(List.of("Authorization"));
	        cfg.setMaxAge(3600L);
	        return cfg;
	    };
	}

	
}
